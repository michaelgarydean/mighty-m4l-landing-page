# mighty-m4l-landing-page

## Technologies
HTML
SASS / CSS
Javascript

## Third-party & Dependencies
Mailchimp
Gumroad

## URL
http://mightym4l.com/
